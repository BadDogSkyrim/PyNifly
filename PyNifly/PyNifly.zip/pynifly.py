
import os
import struct
from math import asin, atan2, pi 
import ctypes
nifly_path = r"D:/OneDrive/Dev/NiflyDLL/NiflyDLL/x64/Debug/NiflyDLL.dll"
test_file = r"tests/test.nif"

game_versions = ["FO3", "FONV", "SKYRIM", "FO4", "SKYRIMSE", "FO4VR", "SKYRIMVR", "FO76"]

def load_nifly():
    nifly = ctypes.cdll.LoadLibrary(nifly_path)
    nifly.load.argtypes = [ctypes.c_char_p]
    nifly.load.restype = ctypes.c_void_p
    nifly.getAllShapeNames.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
    nifly.getAllShapeNames.restype = ctypes.c_int
    nifly.getRootName.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
    nifly.getRootName.restype = ctypes.c_int
    nifly.getGameName.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
    nifly.getGameName.restype = ctypes.c_int
    nifly.getShapeName.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
    nifly.getShapeName.restype = ctypes.c_int
    nifly.destroy.argtypes = [ctypes.c_void_p]
    nifly.destroy.restype = None
    nifly.getShapes.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    nifly.getShapes.restype = ctypes.c_int
    nifly.getRawVertsForShape.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    nifly.getRawVertsForShape.restype = ctypes.c_int
    nifly.getVertsForShape.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    nifly.getVertsForShape.restype = ctypes.c_int
    nifly.getTriangles.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    nifly.getTriangles.restype = ctypes.c_int
    nifly.getTransform.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    nifly.getTransform.restype = None
    nifly.getNodeTransform.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    nifly.getNodeTransform.restype = None
    nifly.getNodeCount.argtypes = [ctypes.c_void_p]
    nifly.getNodeCount.restype = ctypes.c_int
    nifly.getNodes.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    nifly.getNodes.restype = None
    nifly.getNodeName.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int]
    nifly.getNodeName.restype = ctypes.c_int
    nifly.getUVs.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_int]
    nifly.getUVs.restype = ctypes.c_int
    nifly.getShapeBoneCount.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
    nifly.getShapeBoneCount.restype = ctypes.c_int
    nifly.getShapeBoneNames.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_char_p, ctypes.c_int]
    nifly.getShapeBoneNames.restype = ctypes.c_int
    nifly.getShapeBoneIDs.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int]
    nifly.getShapeBoneIDs.restype = ctypes.c_int
    nifly.getShapeBoneWeightsCount.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int]
    nifly.getShapeBoneWeightsCount.restype = ctypes.c_int
    nifly.getShapeBoneWeights.argtypes = [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_int]
    nifly.getShapeBoneWeights.restype = ctypes.c_int
    nifly.createNif.argtypes = [ctypes.c_char_p]
    nifly.createNif.restype = ctypes.c_void_p
    nifly.saveNif.argtypes = [ctypes.c_void_p, ctypes.c_char_p]
    nifly.saveNif.restype = ctypes.c_int
    nifly.createNifShapeFromData.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_int, ctypes.c_void_p, ctypes.c_int]
    return nifly

# --- Helper Routines --- #
def to_euler_angles(rm):
    if rm[0][2] < 1.0:
        if rm[0][2] > -1.0:
            y = atan2(-rm[1][2], rm[2][2])
            p = asin(rm[0][2])
            r = atan2(-rm[0][1], rm[0][0])
        else:
            y = atan2(rm[1][0], rm[1][1])
            p = pi/2.0
            r = 0.0
    else:
        y = atan2(rm[1][0], rm[1][1])
        p = pi/2.0
        r = 0.0
    return (y, p, r)

def to_euler_degrees(rm):
    angles = to_euler_angles(rm)
    return (angles[0] * 180.0/pi, angles[1] * 180.0/pi, angles[2] * 180.0/pi)
    
class BoneWeight(ctypes.Structure):
    _fields_ = [("vertex", ctypes.c_uint16),
                ("weight", ctypes.c_float)]

def SeparateVertsByUV(verts, loops, polys, uvs):
    vertcount = [0] * len(verts)
    for l in loops:
        if vertcount[l[0]] == 0:
            vertcount[l[0]] = 1
        else:
            new_vert = len(verts)
            verts.append(verts[vert_index])
            l[0] = new_vert
            
            

# --- NiNode --- #
class NiNode:
    def __init__(self, parent, self_ref):
        self._handle = self_ref
        self.parent = parent

        buf = ctypes.create_string_buffer(51)
        NifFile.nifly.getNodeName(self._handle, buf, 51)
        self.name = buf.value.decode('utf-8')
        
        XFBUF = ctypes.c_float * 13
        buf = XFBUF()
        NifFile.nifly.getNodeTransform(self._handle, buf)
        self.location = (buf[0], buf[1], buf[2])
        self.rotation = ((buf[3], buf[4], buf[5]), (buf[6], buf[7], buf[8]), (buf[9], buf[10], buf[11]))
        self.scale = buf[12]

# --- NifShape --- #
class NiShape:
    def __init__(self, theNif, theShapeRef):
        self.parent = theNif
        self._handle = theShapeRef
        self._bone_names = None
        self._bone_ids = None
        self._weights = None
        
        buf = ctypes.create_string_buffer(50)
        NifFile.nifly.getShapeName(theShapeRef, buf, 50)
        self.name = buf.value.decode('utf-8')
        
        XFBUF = ctypes.c_float * 4
        buf = XFBUF()
        NifFile.nifly.getTransform(theShapeRef, buf)
        self.location = (buf[0], buf[1], buf[2])
        self.scale = buf[3]

    @property
    def rawVerts(self):
        BUFSIZE = 1000
        VERTBUF = ctypes.c_float * 3 * BUFSIZE
        verts = VERTBUF()
        out = []
        readSoFar = 0
        remainingCount = 0
        while (readSoFar == 0) or (remainingCount > 0):
            totalCount = NifFile.nifly.getRawVertsForShape(
                self.parent._handle, self._handle, verts, BUFSIZE, readSoFar)
            if readSoFar == 0:
                remainingCount = totalCount
            if remainingCount > 0:
                for i in range(0, min(remainingCount, BUFSIZE)):
                    out.append((verts[i][0], verts[i][1], verts[i][2]))
            remainingCount -= BUFSIZE
            readSoFar += BUFSIZE
        return out

    @property
    def verts(self):
        BUFSIZE = 1000
        VERTBUF = ctypes.c_float * 3 * BUFSIZE
        verts = VERTBUF()
        out = []
        readSoFar = 0
        remainingCount = 0
        while (readSoFar == 0) or (remainingCount > 0):
            totalCount = NifFile.nifly.getVertsForShape(
                self.parent._handle, self._handle, verts, BUFSIZE, readSoFar)
            if readSoFar == 0:
                remainingCount = totalCount
            if remainingCount > 0:
                for i in range(0, min(remainingCount, BUFSIZE)):
                    out.append((verts[i][0], verts[i][1], verts[i][2]))
            remainingCount -= BUFSIZE
            readSoFar += BUFSIZE
        return out

    @property
    def tris(self):
        BUFSIZE = 1000
        TRIBUF = ctypes.c_uint16 * 3 * BUFSIZE
        tris = TRIBUF()
        out = []
        readSoFar = 0
        remainingCount = 0
        while (readSoFar == 0) or (remainingCount > 0):
            totalCount = NifFile.nifly.getTriangles(
                self.parent._handle, self._handle, tris, BUFSIZE, readSoFar)
            if readSoFar == 0:
                remainingCount = totalCount
            if remainingCount > 0:
                for i in range(0, min(remainingCount, BUFSIZE)):
                    out.append((tris[i][0], tris[i][1], tris[i][2]))
            remainingCount -= BUFSIZE
            readSoFar += BUFSIZE
        return out

    @property
    def uv(self):
        BUFSIZE = 1000
        UVBUF = ctypes.c_float * 2 * BUFSIZE
        buf = UVBUF()
        out = []
        readSoFar = 0
        remainingCount = 0
        while (readSoFar == 0) or (remainingCount > 0):
            totalCount = NifFile.nifly.getUVs(
                self.parent._handle, self._handle, buf, BUFSIZE, readSoFar)
            if readSoFar == 0:
                remainingCount = totalCount
            if remainingCount > 0:
                for i in range(0, min(remainingCount, BUFSIZE)):
                    out.append((buf[i][0], buf[i][1]))
            remainingCount -= BUFSIZE
            readSoFar += BUFSIZE
        return out

    @property
    def bone_names(self):
        if self._bone_names is None:
            bufsize = 300
            buf = ctypes.create_string_buffer(bufsize+1)
            actualsize = NifFile.nifly.getShapeBoneNames(self.parent._handle, self._handle, buf, bufsize)
            if actualsize > bufsize:
                buf = ctypes.create_string_buffer(actualsize+1)
                NifFile.nifly.getShapeBoneNames(self.parent._handle, self._handle, buf, actualsize+1)
            self._bone_names = buf.value.decode('utf-8').split('\n')
        return self._bone_names
        
    @property
    def bone_ids(self):
        if self._bone_ids is None:
            id_count = NifFile.nifly.getShapeBoneCount(self.parent._handle, self._handle)
            BUFDEF = ctypes.c_int * id_count
            buf = BUFDEF()
            NifFile.nifly.getShapeBoneIDs(self.parent._handle, self._handle, buf, id_count)
            self._bone_ids = list(buf)
        return self._bone_ids

    def _bone_weights(self, bone_id):
        # Weights for all vertices (that are weighted to it)
        BUFSIZE = NifFile.nifly.getShapeBoneWeightsCount(self.parent._handle, self._handle, bone_id)
        BUFDEF = BoneWeight * BUFSIZE
        buf = BUFDEF()
        NifFile.nifly.getShapeBoneWeights(self.parent._handle, self._handle, bone_id, buf, BUFSIZE)
        out = [(x.vertex, x.weight) for x in buf]
        return out

    @property
    def bone_weights(self):
        if self._weights is None:
            self._weights = {}
            for bone_idx, name in enumerate(self.bone_names):
                self._weights[name] = self._bone_weights(bone_idx)
        return self._weights

# --- NifFile --- #
class NifFile:
    nifly = load_nifly()
    
    def __init__(self, filepath=None):
        self.filepath = filepath
        self._handle = None
        if not filepath is None:
            self._handle = NifFile.nifly.load(filepath.encode('utf-8'))
        self._shapes = None
        self._nodes = None

    def __del__(self):
        NifFile.nifly.destroy(self._handle)

    def initialize(self, target_game, filepath):
        self.filepath = filepath
        self._handle = NifFile.nifly.createNif(target_game.encode('utf-8'))

    def save(self):
        NifFile.nifly.saveNif(self._handle, self.filepath.encode('utf-8'))

    def createShapeFromData(self, shape_name, verts, tris, uvs):
        VERTBUFDEF = ctypes.c_float * 3 * len(verts)
        vertbuf = VERTBUFDEF()
        for i, v in enumerate(verts): vertbuf[i] = v
        TRIBUFDEF = ctypes.c_int * 3 * len(tris)
        tribuf = TRIBUFDEF()
        for i, t in enumerate(tris): tribuf[i] = t
        UVBUFDEF = ctypes.c_float * 2 * len(uvs)
        uvbuf = UVBUFDEF()
        for i, u in enumerate(uvs): uvbuf[i] = (u[0], 1-u[1])
        NifFile.nifly.createNifShapeFromData(
            self._handle, 
            shape_name.encode('utf-8'), 
            vertbuf, len(verts)*3, 
            tribuf, len(tris)*3, 
            uvbuf, len(uvs)*2, 
            None, 0)

    @property
    def rootName(self):
        """Return name of root node"""
        buf = ctypes.create_string_buffer(50)
        NifFile.nifly.getRootName(self._handle, buf, 50)
        return buf.value.decode('utf-8')
    
    @property
    def game(self):
        """Return name of the game the Nif file is for"""
        buf = ctypes.create_string_buffer(50)
        NifFile.nifly.getGameName(self._handle, buf, 50)
        return buf.value.decode('utf-8')
    
    def getAllShapeNames(self):
        buf = ctypes.create_string_buffer(300)
        NifFile.nifly.getAllShapeNames(self._handle, buf, 300)
        return buf.value.decode('utf-8').split('\n')

    @property
    def shapes(self):
        if self._shapes is None:
            self._shapes = []
            PTRBUF = ctypes.c_void_p * 30
            buf = PTRBUF()
            nfound = NifFile.nifly.getShapes(self._handle, buf, 30, 0)
            for i in range(min(nfound, 30)):
                self._shapes.append(NiShape(self, buf[i])) # not handling too many shapes yet
        return self._shapes

    @property
    def nodes(self):
        if self._nodes is None:
            self._nodes = {}
            nodeCount = NifFile.nifly.getNodeCount(self._handle)
            PTRBUF = ctypes.c_void_p * nodeCount
            buf = PTRBUF()
            NifFile.nifly.getNodes(self._handle, buf)
            for h in buf:
                this_node = NiNode(self, h)
                self._nodes[this_node.name] = this_node
        return self._nodes

# ----------------- ### ------------------ ### ------------------

if __name__ == "__main__":
    print(os.getcwd())

    print(">>NifFile object gives access to a nif")
    f1 = NifFile("tests/skyrim/test.nif")
    print(">>Toplevel node name is available")
    assert f1.game == "SKYRIM", "ERROR: Test file not Skyrim"
    assert f1.rootName == "Scene Root", "ERROR: Test file root name wrong: " + str(f.rootName)

    f2 = NifFile("tests/FO4/AlarmClock.nif")
    assert f2.game == "FO4", "ERROR: Test file not FO4"

    print(">>getAllShapeNames returns names of meshes within the nif")
    print(f1.getAllShapeNames())
    assert f1.getAllShapeNames() == ['Armor', 'MaleBody'], 'ERROR: Test shape names not correct'
    print(">>Shapes property is a list of the shapes/meshes in the nif")
    assert len(f1.shapes) == 2, "ERROR: Test file does not have 2 shapes"

    print(">>Shapes have names")
    assert f1.shapes[0].name == "Armor", "ERROR: first shape name not 'Armor'"

    print(">>Shapes rawVerts property is a list of triples containing x,y,z position")
    f2 = NifFile("tests/skyrim/noblecrate01.nif")
    print(f2.getAllShapeNames())
    verts = f2.shapes[0].rawVerts
    assert len(verts) == 686, "ERROR: Did not import 686 verts"
    assert round(verts[0][0], 4) == -67.6339, "ERROR: First vert wrong"
    assert round(verts[0][1], 4) == -24.8498, "ERROR: First vert wrong"
    assert round(verts[0][2], 4) == 0.2476, "ERROR: First vert wrong"
    assert round(verts[685][0], 4) == -64.4469, "ERROR: Last vert wrong"
    assert round(verts[685][1], 4) == -16.3246, "ERROR: Last vert wrong"
    assert round(verts[685][2], 4) == 26.4362, "ERROR: Last vert wrong"
  

    print(">>Shapes tris property is a list of triples defining the triangles")
    tris = f2.shapes[0].tris
    assert len(tris) == 258, "ERROR: Did not import 258 tris"
    assert tris[0] == (0, 1, 2), "ERROR: First tri incorrect"
    assert tris[1] == (2, 3, 0), "ERROR: Second tri incorrect"

    print(">>Can access verts and tris of second shape too;")
    print(">>  Can access verts and tris from beyond the first buffer limit")
    verts = f1.shapes[1].rawVerts 
    assert len(verts) == 2024, "ERROR: Wrong vert count for second shape - " + str(len(f1.shapes[1].rawVerts))

    assert round(verts[0][0], 4) == 0.0, "ERROR: First vert wrong"
    assert round(verts[0][1], 4) == 8.5051, "ERROR: First vert wrong"
    assert round(verts[0][2], 4) == 96.5766, "ERROR: First vert wrong"
    assert round(verts[2023][0], 4) == -4.4719, "ERROR: Last vert wrong"
    assert round(verts[2023][1], 4) == 8.8933, "ERROR: Last vert wrong"
    assert round(verts[2023][2], 4) == 92.3898, "ERROR: Last vert wrong"
    tris = f1.shapes[1].tris
    assert len(tris) == 3680, "ERROR: Wrong tri count for second shape - " + str(len(f1.shapes[1].tris))
    assert tris[0][0] == 0, "ERROR: First tri wrong"
    assert tris[0][1] == 1, "ERROR: First tri wrong"
    assert tris[0][2] == 2, "ERROR: First tri wrong"
    assert tris[3679][0] == 85, "ERROR: Last tri wrong"
    assert tris[3679][1] == 93, "ERROR: Last tri wrong"
    assert tris[3679][2] == 88, "ERROR: Last tri wrong"

    print(">>Shapes have translation and scale")
    assert f1.shapes[1].location == (0.0, 0.0, 0.0), "ERROR: Body location not 0"
    assert f1.shapes[1].scale == 1.0, "ERROR: Body scale not 1"
    assert list(round(x, 4) for x in f1.shapes[0].location) == [-0.0003, -1.5475, 120.3436], "ERROR: Armor location not correct"

    print(">>Shapes have UVs")
    uv = f2.shapes[0].uv
    assert len(uv) == 686, "ERROR: UV count not correct"
    assert list(round(x, 4) for x in uv[0]) == [0.4164, 0.419], "ERROR: First UV wrong"
    assert list(round(x, 4) for x in uv[685]) == [0.4621, 0.4327], "ERROR: First UV wrong"
    
    print(">>Nifs contain a set of bones (nodes with transforms)")
    assert len(f1.nodes) == 30, "ERROR: Number of bones incorrect"
    assert f1.nodes["NPC R UpperarmTwist2 [RUt2]"].name == "NPC R UpperarmTwist2 [RUt2]", "ERROR: Node name wrong"
    assert [round(x, 4) for x in f1.nodes["NPC R UpperarmTwist2 [RUt2]"].location] == [15.8788, -5.1873, 100.1124], "ERROR: Location incorrect"
    assert [round(x, 2) for x in to_euler_degrees(f1.nodes["NPC R UpperarmTwist2 [RUt2]"].rotation)] == [10.40, 65.25, -9.13], "ERROR: Rotation incorrect"

    print(">>Shapes reference bones")
    try:
        assert f1.shapes[1].bone_names.index('NPC Spine [Spn0]') >= 0, "ERROR: Wierd stuff just happened"
    except:
        print("ERROR: Did not find bone in list")
    print(">>Bones have IDs")
    assert len(f1.shapes[1].bone_ids) == len(f1.shapes[1].bone_names), "ERROR: Mismatch between names and IDs"
    assert len(f1.shapes[1].bone_weights['NPC L Foot [Lft ]']) == 13, "ERRROR: Wrong number of bone weights"

    print(">>Can create new files with content: tetrahedron")
    verts = [(0.0, 0.0, 0.0),
             (2.0, 0.0, 0.0),
             (2.0, 2.0, 0.0),
             (1.0, 1.0, 2.0),
             (1.0, 1.0, 2.0),
             (1.0, 1.0, 2.0)]
    tris = [(2, 1, 0),
            (1, 3, 0),
            (2, 4, 1),
            (5, 2, 0)]
    uvs = [(0.4370, 0.8090),
           (0.7460, 0.5000),
           (0.4370, 0.1910),
           (0.9369, 1.0),
           (0.9369, 0.0),
           (0.0, 0.5000) ]
    newf = NifFile()
    newf.initialize("SKYRIM", "tests/out/testnew01.nif")
    newf.createShapeFromData("FirstShape", verts, tris, uvs)
    newf.save()

    newf_in = NifFile("tests/out/testnew01.nif")
    assert newf_in.shapes[0].name == "FirstShape", "ERROR: Didn't get expected shape back"
    
    newf2 = NifFile()
    newf2.initialize("FO4", "tests/out/testnew02.nif")
    newf2.createShapeFromData("FirstShape", verts, tris, uvs)
    newf2.save()

    newf2_in = NifFile("tests/out/testnew02.nif")
    assert newf2_in.shapes[0].name == "FirstShape", "ERROR: Didn't get expected shape back"

