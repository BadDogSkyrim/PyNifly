"""NIF format export/import for Blender using Nifly"""

# Copyright © 2021, Bad Dog.

bl_info = {
    "name": "NIF format",
    "description": "Import/Export for Skyrim, Skyrim SE, and Fallout 4 NIF files (*.nif)",
    "author": "Bad Dog",
    "blender": (2, 92, 0),
    "version": (0, 0, 1), 
    "location": "File > Import-Export",
    "warning": "WIP",
    "support": "COMMUNITY",
    "category": "Import-Export"
}

import sys
import os.path
from operator import or_
from functools import reduce

sys.path.append(r"D:\OneDrive\Dev\PyNifly\PyNifly")
from pynifly import *
from niflytools import *

import bpy
from bpy.props import (
        BoolProperty,
        FloatProperty,
        StringProperty,
        EnumProperty,
        )
from bpy_extras.io_utils import (
        ImportHelper,
        ExportHelper)
import bmesh

nifly_path = r"D:/OneDrive/Dev/NiflyDLL/NiflyDLL/x64/Debug/NiflyDLL.dll"
test_file = r"D:/OneDrive/Dev/PyNifly/PyNifly/tests/test.nif"

def mesh_create_uv(the_mesh, uv_points):
    # Create UV in Blender to match UVpoints from Nif
    new_uv = [(0,0)] * len(the_mesh.data.loops)
    for lp_idx, lp in enumerate(the_mesh.data.loops):
        vert_targeted = lp.vertex_index
        new_uv[lp_idx] = (uv_points[vert_targeted][0], 1-uv_points[vert_targeted][1])
    new_uvlayer = the_mesh.data.uv_layers.new(do_init=False)
    for i, this_uv in enumerate(new_uv):
        new_uvlayer.data[i].uv = this_uv

def mesh_create_groups(the_shape, the_object):
    vg = the_object.vertex_groups
    for bone_name in the_shape.bone_names:
        new_vg = vg.new(name=bone_name)
        for v, w in the_shape.bone_weights[bone_name]:
            new_vg.add((v,), w, 'ADD')
    
def make_obj_from_shape(the_shape):
    v = the_shape.verts
    t = the_shape.tris
    new_mesh = bpy.data.meshes.new(the_shape.name)
    new_mesh.from_pydata(v, [], t)
    new_object = bpy.data.objects.new(the_shape.name, new_mesh)
    new_object.scale = (the_shape.scale, the_shape.scale, the_shape.scale)
    new_object.location = the_shape.location
    # new_object.rotation = ? not handling rotation yet 
    mesh_create_uv(new_object, the_shape.uv)
    mesh_create_groups(the_shape, new_object)
    for f in new_mesh.polygons:
        f.use_smooth = True
    new_mesh.update(calc_edges=True, calc_edges_loose=True)
    new_mesh.validate(verbose=True)
    return new_object

def make_armature(the_coll, the_nif, bone_names):
    arm_data = bpy.data.armatures.new(the_nif.rootName)
    arm_ob = bpy.data.objects.new(the_nif.rootName, arm_data)
    the_coll.objects.link(arm_ob)
    arm_ob.select_set(True)
    bpy.context.view_layer.objects.active = arm_ob

    bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
    bpy.ops.object.mode_set(mode='EDIT', toggle=False)
    
    for name in bone_names:
        bone =  arm_data.edit_bones.new(name)
        loc = the_nif.nodes[name].location
        bone.head = loc
        bone.tail = list(map(sum, zip(loc, (5.0, 0.0, 0.0))))
        
    bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
    return arm_ob
    
class ImportNIF(bpy.types.Operator, ImportHelper):
    """Load a NIF File"""
    bl_idname = "import_scene.nifly"
    bl_label = "Import NIF (Nifly)"
    bl_options = {'PRESET', 'UNDO'}

    filename_ext = ".nif"
#    filter_glob = StringProperty(
#            default="*.nif",
#            options={'HIDDEN'},
#            )

    def execute(self, context):
        print('BD NIF IMPORT!')
        print('Filepath: ' + self.filepath)
        bpy.ops.object.select_all(action='DESELECT')
        skel = None
        f = NifFile(self.filepath)
        sourceGame = f.game
        new_collection = bpy.data.collections.new(os.path.basename(f.filepath))
        bpy.context.scene.collection.children.link(new_collection)
#        if len(f.nodes) > 1:
#            skel = make_armature(f)
#            new_collection.objects.link(skel)
        sourceSkel = gameSkeletons[sourceGame][1]
        bones = set()
        new_objs = []

        for s in f.shapes:
            obj = make_obj_from_shape(s)
            new_objs.append(obj)
            new_collection.objects.link(obj)
            for n in s.bone_names: 
                if sourceSkel.has_key(n):
                    bones.add(n) 

        if len(bones) > 0:
            print("Found bones, creating skeleton: " + str(bones))
            skel = make_armature(new_collection, f, bones)
            for o in new_objs: o.select_set(True)
            bpy.ops.object.parent_set(type='ARMATURE_NAME', xmirror=False, keep_transform=False)
        
        # --- VALIDATE THE MESH HERE ---
        return {'FINISHED'}

class ExportNIF(bpy.types.Operator, ExportHelper):
    """Save a NIF File"""

    bl_idname = "export_scene.nifly"
    bl_label = 'Export NIF (Nifly)'
    bl_options = {'PRESET'}

    filename_ext = ".nif"

    def execute(self, context):
        print('BD NIF EXPORT!')
        exportf = NifFile()
        exportf.initialize("SKYRIM", self.filepath)
        obj = bpy.context.object
        mesh = obj.data
        
        print("Triangulating mesh")
        bm = bmesh.new()
        bm.from_mesh(mesh)
        
        bmesh.ops.triangulate(bm, faces=bm.faces[:])
        verts = [v.co[:] for v in bm.verts]
        
        uv_lay = bm.loops.layers.uv.active
        loops = []
        uvs = []
        polyloops = []
        for f in bm.faces:
            polyloops.append(len(loops))
            for seg in f.loops:
                loops.append(seg.vert.index)
                uvs.append(seg[uv_lay].uv[:])
        
        print("--Initial mesh--")
        print(obj.name)
        print(verts)
        print(loops)
        print(uvs)
        print(polyloops)
        
        mesh_split_by_uv(verts, loops, uvs)
        
        uvmap_new = [uvs[loops.index(i)] for i in range(0, len(verts))]
        polyverts = [(loops[seg], loops[seg+1], loops[seg+2]) for seg in polyloops]
        
        print("--Split mesh--")
        print(obj.name)
        print(verts)
        print(uvmap_new)
        print(polyverts)

        bm.free()
        
        if len(verts) != len(uvmap_new):
            print("ERROR': Splitting mesh resulted in invalid number of verts/UVs (%d/%d)" % (len(verts), len(uvmap_new)))
            return {'CANCELLED'}
        else:
            exportf.createShapeFromData(obj.name, verts, polyverts, uvmap_new)
            exportf.save()
            return {'FINISHED'}

def menu_func_import(self, context):
    self.layout.operator(ImportNIF.bl_idname, text="Nif file with Nifly (.nif)")
def menu_func_export(self, context):
    self.layout.operator(ExportNIF.bl_idname, text="Nif file with Nifly (.nif)")

def register():
    bpy.utils.register_class(ImportNIF)
    bpy.utils.register_class(ExportNIF)
    bpy.types.TOPBAR_MT_file_import.append(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)

def unregister():
    bpy.types.TOPBAR_MT_file_import.remove(menu_func_import)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    bpy.utils.unregister_class(ImportNIF)
    bpy.utils.unregister_class(ExportNIF)

if __name__ == "__main__":
    register()
