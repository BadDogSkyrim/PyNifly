""" Simple tools doing mesh operations to support import/export"""

def uv_location(uv):
    return (round(uv[0], 4), round(uv[1], 4))

def mesh_split_by_uv(verts, loops, uvmap):
    """Split a mesh represented by parameters and split verts to follow the UV map
        verts = [(x, y, z), ...] vertex locations
        loops = [int, ...] blender-style loops--elements are indices into verts
        uvmap = [(u, v), ...] uvmap--matches 1:1 with loops
    Returns
        verts = extended with additional verts where splits were required
        loops = modified to reference the new verts where needed
        uvmap = not changed
    """
    # Build a dictionary of vert locations
    
    # Walk the loops. If the associated UV puts the vert in a new location, dup the vert
    vert_locs = [None] * len(verts)
    for i, vert_idx in enumerate(loops):
        this_vert_loc = uv_location(uvmap[i])
        if vert_locs[vert_idx] is None:
            # Not given this vert a location yet
            vert_locs[vert_idx] = this_vert_loc
        elif vert_locs[vert_idx] != this_vert_loc:
            # Found already at different location
            #print("Splitting vert #%d, referenced by loop #%d: %s != %s" % 
            #    (vert_idx, i, str(uvmap[i]), str(vert_locs[vert_idx])))
            new_index = len(verts)
            verts.append(verts[vert_idx])
            vert_locs.append(this_vert_loc)
            loops[i] = new_index
            # And any verts further down the list at this loc get updated too
            for j in range(i+1, len(loops)-1):
                #print("Checking additional at %d: %s == %s" % (j, str(uv_location(uvmap[loops[j]])), str(this_vert_loc)))
                if uv_location(uvmap[j]) == this_vert_loc:
                    #print("Updating at %d too" % (j))
                    loops[j] = new_index

blenderToSkyrimBones = {
    'NPC Calf [Clf].L': 'NPC L Calf [LClf]',
    'NPC Calf [Clf].R':'NPC R Calf [RClf]',
    'NPC Clavicle [Clv].L': 'NPC L Clavicle [LClv]',
    'NPC Clavicle [Clv].R': 'NPC R Clavicle [RClv]',
    'NPC Finger00 [F00].L': 'NPC L Finger00 [LF00]',
    'NPC Finger00 [F00].R': 'NPC R Finger00 [RF00]',
    'NPC Finger01 [F01].L': 'NPC L Finger01 [LF01]',
    'NPC Finger01 [F01].R': 'NPC R Finger01 [RF01]',
    'NPC Finger02 [F02].L': 'NPC L Finger02 [LF02]',
    'NPC Finger02 [F02].R': 'NPC R Finger02 [RF02]',
    'NPC Finger10 [F10].L': 'NPC L Finger10 [LF10]',
    'NPC Finger10 [F10].R': 'NPC R Finger10 [RF10]',
    'NPC Finger11 [F11].L': 'NPC L Finger11 [LF11]',
    'NPC Finger11 [F11].R': 'NPC R Finger11 [RF11]',
    'NPC Finger12 [F12].L': 'NPC L Finger12 [LF12]',
    'NPC Finger12 [F12].R': 'NPC R Finger12 [RF12]',
    'NPC Finger20 [F20].L': 'NPC L Finger20 [LF20]',
    'NPC Finger20 [F20].R': 'NPC R Finger20 [RF20]',
    'NPC Finger21 [F21].L': 'NPC L Finger21 [LF21]',
    'NPC Finger21 [F21].R': 'NPC R Finger21 [RF21]',
    'NPC Finger22 [F22].L': 'NPC L Finger22 [LF22]',
    'NPC Finger22 [F22].R': 'NPC R Finger22 [RF22]',
    'NPC Finger30 [F30].L': 'NPC L Finger30 [LF30]',
    'NPC Finger30 [F30].R': 'NPC R Finger30 [RF30]',
    'NPC Finger31 [F31].L': 'NPC L Finger31 [LF31]',
    'NPC Finger31 [F31].R': 'NPC R Finger31 [RF31]',
    'NPC Finger32 [F32].L': 'NPC L Finger32 [LF32]',
    'NPC Finger32 [F32].R': 'NPC R Finger32 [RF32]',
    'NPC Finger40 [F40].L': 'NPC L Finger40 [LF40]',
    'NPC Finger40 [F40].R': 'NPC R Finger40 [RF40]',
    'NPC Finger41 [F41].L': 'NPC L Finger41 [LF41]',
    'NPC Finger41 [F41].R': 'NPC R Finger41 [RF41]',
    'NPC Finger42 [F42].L': 'NPC L Finger42 [LF42]',
    'NPC Finger42 [F42].R': 'NPC R Finger42 [RF42]',
    'NPC Foot [ft ].L':'NPC L Foot [Lft ]',
    'NPC Foot [ft ].R':'NPC R Foot [Rft ]',
    'NPC Forearm [Lar].R': 'NPC R Forearm [RLar]',
    'NPC Forearm [Lar].L': 'NPC L Forearm [LLar]',
    'NPC ForearmTwist1 [Lt1].L': 'NPC L ForearmTwist1 [LLt1]',
    'NPC ForearmTwist1 [Lt1].R': 'NPC R ForearmTwist1 [RLt1]',
    'NPC ForearmTwist2 [Lt2].L': 'NPC L ForearmTwist2 [LLt2]',
    'NPC ForearmTwist2 [Lt2].R': 'NPC R ForearmTwist2 [RLt2]',
    'NPC Hand [Hnd].L': 'NPC L Hand [LHnd]',
    'NPC Hand [Hnd].R': 'NPC R Hand [RHnd]',
    'NPC Thigh [Thg].L': 'NPC L Thigh [LThg]',
    'NPC Thigh [Thg].R': 'NPC R Thigh [RThg]',
    'NPC Toe0 [Toe].L':'NPC L Toe0 [LToe]',
    'NPC Toe0 [Toe].R':'NPC R Toe0 [RToe]',
    'NPC UpperArm [Uar].L': 'NPC L UpperArm [LUar]',
    'NPC UpperArm [Uar].R': 'NPC R UpperArm [RUar]',
    'NPC UpperarmTwist1 [Ut1].L': 'NPC L UpperarmTwist1 [LUt1]',
    'NPC UpperarmTwist1 [Ut1].R': 'NPC R UpperarmTwist1 [RUt1]',
    'NPC UpperarmTwist2 [Ut2].L': 'NPC L UpperarmTwist2 [LUt2]',
    'NPC UpperarmTwist2 [Ut2].R': 'NPC R UpperarmTwist2 [RUt2]' }

skyrimToBlenderBones = {}
for k in blenderToSkyrimBones.keys():
    skyrimToBlenderBones[blenderToSkyrimBones[k]] = k;

blenderToFO4Bones = {
    'Root': ('Root', None),
    'Pelvis': ('Pelvis', 'Root'),
    'SPINE1': ('SPINE1', 'Pelvis'),
    'SPINE2': ('SPINE2', 'SPINE1'),
    'Chest': ('Chest', 'SPINE2'),
    'LArm_Collarbone': ('Arm_Collarbone.L', 'Chest'),
    'LArm_UpperArm': ('Arm_UpperArm.L', 'Arm_Collarbone.L'),
    'LArm_Collarbone_skin': ('Arm_Collarbone_skin.L', 'Arm_Collarbone.L'),
    'LArm_ShoulderFat_skin': ('Arm_ShoulderFat_skin.L', 'Arm_Collarbone.L'),
    'LArm_ForeArm1': ('Arm_ForeArm1.L', 'Arm_UpperArm.L'),
    'LArm_UpperTwist1': ('Arm_UpperTwist1.L', 'Arm_UpperArm.L'),
    'LArm_UpperArm_skin': ('Arm_UpperArm_skin.L', 'Arm_UpperArm.L'),
    'LArm_UpperTwist2': ('Arm_UpperTwist2.L', 'Arm_UpperTwist1.L'),
    'LArm_UpperFat_skin': ('Arm_UpperFat_skin.L', 'Arm_UpperTwist2.L'),
    'LArm_UpperTwist2_skin': ('Arm_UpperTwist2_skin.L', 'Arm_UpperTwist2.L'),
    'LArm_ForeArm2': ('Arm_ForeArm2.L', 'Arm_ForeArm1.L'),
    'LArm_ForeArm1_skin': ('Arm_ForeArm1_skin.L', 'Arm_ForeArm1.L'),
    'LArm_ForeArm3': ('Arm_ForeArm3.L', 'Arm_ForeArm2.L'),
    'LArm_ForeArm2_skin': ('Arm_ForeArm2_skin.L', 'Arm_ForeArm2.L'),
    'LArm_Hand': ('Arm_Hand.L', 'Arm_ForeArm3.L'),
    'PipboyBone': ('PipboyBone', 'Arm_ForeArm3.L'),
    'LArm_ForeArm3_skin': ('Arm_ForeArm3_skin.L', 'Arm_ForeArm3.L'),
    'LArm_Finger11': ('Arm_Finger11.L', 'Arm_Hand.L'),
    'LArm_Finger21': ('Arm_Finger21.L', 'Arm_Hand.L'),
    'LArm_Finger31': ('Arm_Finger31.L', 'Arm_Hand.L'),
    'LArm_Finger41': ('Arm_Finger41.L', 'Arm_Hand.L'),
    'LArm_Finger51': ('Arm_Finger51.L', 'Arm_Hand.L'),
    'LArm_Finger12': ('Arm_Finger12.L', 'Arm_Finger11.L'),
    'LArm_Finger13': ('Arm_Finger13.L', 'Arm_Finger12.L'),
    'LArm_Finger22': ('Arm_Finger22.L', 'Arm_Finger21.L'),
    'LArm_Finger23': ('Arm_Finger23.L', 'Arm_Finger22.L'),
    'LArm_Finger32': ('Arm_Finger32.L', 'Arm_Finger31.L'),
    'LArm_Finger33': ('Arm_Finger33.L', 'Arm_Finger32.L'),
    'LArm_Finger42': ('Arm_Finger42.L', 'Arm_Finger41.L'),
    'LArm_Finger43': ('Arm_Finger43.L', 'Arm_Finger42.L'),
    'LArm_Finger52': ('Arm_Finger52.L', 'Arm_Finger51.L'),
    'LArm_Finger53': ('Arm_Finger53.L', 'Arm_Finger52.L'),
    'WeaponLeft': ('Weapon.L', 'Arm_Hand.L'),
    'AnimObjectL1': ('AnimObject1.L', 'Arm_Hand.L'),
    'AnimObjectL2': ('AnimObject2.L', 'Arm_Hand.L'),
    'AnimObjectL3': ('AnimObject3.L', 'Arm_Hand.L'),
    'Neck': ('Neck', 'Chest'),
    'RArm_Collarbone': ('Arm_Collarbone.R', 'Chest'),
    'RArm_UpperArm': ('Arm_UpperArm.R', 'Arm_Collarbone.R'),
    'RArm_Collarbone_skin': ('Arm_Collarbone_skin.R', 'Arm_Collarbone.R'),
    'RArm_ShoulderFat_skin': ('Arm_ShoulderFat_skin.R', 'Arm_Collarbone.R'),
    'RArm_ForeArm1': ('Arm_ForeArm1.R', 'Arm_UpperArm.R'),
    'RArm_UpperTwist1': ('Arm_UpperTwist1.R', 'Arm_UpperArm.R'),
    'RArm_UpperArm_skin': ('Arm_UpperArm_skin.R', 'Arm_UpperArm.R'),
    'RArm_UpperTwist2': ('Arm_UpperTwist2.R', 'Arm_UpperTwist1.R'),
    'RArm_UpperTwist2_skin': ('Arm_UpperTwist2_skin.R', 'Arm_UpperTwist2.R'),
    'RArm_UpperFat_skin': ('Arm_UpperFat_skin.R', 'Arm_UpperTwist2.R'),
    'RArm_ForeArm2': ('Arm_ForeArm2.R', 'Arm_ForeArm1.R'),
    'RArm_ForeArm1_skin': ('Arm_ForeArm1_skin.R', 'Arm_ForeArm1.R'),
    'RArm_ForeArm3': ('Arm_ForeArm3.R', 'Arm_ForeArm2.R'),
    'RArm_ForeArm2_skin': ('Arm_ForeArm2_skin.R', 'Arm_ForeArm2.R'),
    'RArm_Hand': ('Arm_Hand.R', 'Arm_ForeArm3.R'),
    'PipboyBone': ('PipboyBone', 'Arm_ForeArm3.R'),
    'RArm_ForeArm3_skin': ('Arm_ForeArm3_skin.R', 'Arm_ForeArm3.R'),
    'RArm_Finger11': ('Arm_Finger11.R', 'Arm_Hand.R'),
    'RArm_Finger21': ('Arm_Finger21.R', 'Arm_Hand.R'),
    'RArm_Finger31': ('Arm_Finger31.R', 'Arm_Hand.R'),
    'RArm_Finger41': ('Arm_Finger41.R', 'Arm_Hand.R'),
    'RArm_Finger51': ('Arm_Finger51.R', 'Arm_Hand.R'),
    'RArm_Finger12': ('Arm_Finger12.R', 'Arm_Finger11.R'),
    'RArm_Finger13': ('Arm_Finger13.R', 'Arm_Finger12.R'),
    'RArm_Finger22': ('Arm_Finger22.R', 'Arm_Finger21.R'),
    'RArm_Finger23': ('Arm_Finger23.R', 'Arm_Finger22.R'),
    'RArm_Finger32': ('Arm_Finger32.R', 'Arm_Finger31.R'),
    'RArm_Finger33': ('Arm_Finger33.R', 'Arm_Finger32.R'),
    'RArm_Finger42': ('Arm_Finger42.R', 'Arm_Finger41.R'),
    'RArm_Finger43': ('Arm_Finger43.R', 'Arm_Finger42.R'),
    'RArm_Finger52': ('Arm_Finger52.R', 'Arm_Finger51.R'),
    'RArm_Finger53': ('Arm_Finger53.R', 'Arm_Finger52.R'),
    'WEAPON': ('Weapon.R', 'Arm_Hand.R'),
    'AnimObjectR1': ('AnimObject1.R', 'Arm_Hand.R'),
    'AnimObjectR2': ('AnimObject2.R', 'Arm_Hand.R'),
    'AnimObjectR3': ('AnimObject3.R', 'Arm_Hand.R'),
    'L_RibHelper': ('RibHelper.L', 'Chest'),
    'R_RibHelper': ('RibHelper.R', 'Chest'),
    'Chest_skin': ('Chest_skin', 'Chest'),
    'LBreast_skin': ('Breast_skin.L', 'Chest'),
    'RBreast_skin': ('Breast_skin.R', 'Chest'),
    'Chest_Rear_Skin': ('Chest_Rear_Skin', 'Chest'),
    'Chest_Upper_skin': ('Chest_Upper_skin', 'Chest'),
    'Neck_Low_skin': ('Neck_Low_skin', 'Chest'),
    'Spine2_skin': ('Spine2_skin', 'SPINE2'),
    'UpperBelly_skin': ('UpperBelly_skin', 'SPINE2'),
    'Spine2_Rear_skin': ('Spine2_Rear_skin', 'SPINE2'),
    'Spine1_skin': ('Spine1_skin', 'SPINE1'),
    'Belly_skin': ('Belly_skin', 'SPINE1'),
    'Spine1_Rear_skin': ('Spine1_Rear_skin', 'SPINE1')
    }

FO4ToBlenderBones = {}
for k in blenderToFO4Bones.keys():
    FO4ToBlenderBones[blenderToFO4Bones[k]] = k;

gameSkeletons = {
    'SKYRIM': (blenderToSkyrimBones, skyrimToBlenderBones),
    'SKYRIMSE': (blenderToSkyrimBones, skyrimToBlenderBones),
    'FO4': (blenderToFO4Bones, FO4ToBlenderBones)}

if __name__ == "__main__":
# ------------ # TESTS # ------------------ #

    import sys
    import os.path
    sys.path.append(r"D:\OneDrive\Dev\PyNifly\PyNifly")
    from pynifly import *

    print("--Can split verts of standard blender cube, triangularized")
    verts = [(1.0, 1.0, 1.0),
             (1.0, 1.0, -1.0),
             (1.0, -1.0, 1.0),
             (1.0, -1.0, -1.0),
             (-1.0, 1.0, 1.0),
             (-1.0, 1.0, -1.0),
             (-1.0, -1.0, 1.0),
             (-1.0, -1.0, -1.0)]
    loops = [4, 2, 0,
             2, 7, 3,
             6, 5, 7,
             1, 7, 5,
             0, 3, 1,
             4, 1, 5,
             4, 6, 2,
             2, 6, 7,
             6, 4, 5,
             1, 3, 7,
             0, 2, 3,
             4, 0, 1]
    poly_verts = [[4, 2, 0],
                  [2, 7, 3],
                  [6, 5, 7],
                  [1, 7, 5],
                  [0, 3, 1],
                  [4, 1, 5],
                  [4, 6, 2],
                  [2, 6, 7],
                  [6, 4, 5],
                  [1, 3, 7],
                  [0, 2, 3],
                  [4, 0, 1]]
    uvs = [(0.875, 0.5), (0.625, 0.75), (0.625, 0.5),
           (0.625, 0.75), (0.375, 1.0), (0.375, 0.75),
           (0.625, 0.0), (0.375, 0.25), (0.375, 0.0),
           (0.375, 0.5), (0.125, 0.75), (0.125, 0.5),
           (0.625, 0.5), (0.375, 0.75), (0.375, 0.5),
           (0.625, 0.25), (0.375, 0.5), (0.375, 0.25),
           (0.875, 0.5), (0.875, 0.75), (0.625, 0.75),
           (0.625, 0.75), (0.625, 1.0), (0.375, 1.0),
           (0.625, 0.0), (0.625, 0.25), (0.375, 0.25),
           (0.375, 0.5), (0.375, 0.75), (0.125, 0.75),
           (0.625, 0.5), (0.625, 0.75), (0.375, 0.75),
           (0.625, 0.25), (0.625, 0.5), (0.375, 0.5)]
    polyloops = [0, 3, 6, 9, 12, 15, 18, 21, 24, 27, 30, 33]
    
    mesh_split_by_uv(verts, loops, uvs)
    
    assert len(verts) == 14, "Error: wrong number of verts after edge splitting"

    print("--Can create nif from cube")
    poly_verts_new = [(loops[seg], loops[seg+1], loops[seg+2]) for seg in polyloops]
    uvmap_new = [uvs[loops.index(i)] for i in range(0, len(verts))]

    f = NifFile()
    f.initialize("SKYRIM", "tests/out/toolstest01.nif")
    f.createShapeFromData("Cube", verts, poly_verts_new, uvmap_new)
    f.save()
    
   
