# Dummy file to help locating the addon path
